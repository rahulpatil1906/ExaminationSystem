import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import javax.servlet.Servlet;
import org.apache.commons.fileupload.FileUploadException;

@WebServlet("/Hindiquesprocess")
public class Hindiquesprocess  extends HttpServlet implements Servlet {
        @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
         response.setContentType("text/html");  
         PrintWriter out=response.getWriter(); 
        try {

	             String category = "";
	             InputStream csvfile = null;
	
	             FileItemFactory factory = new DiskFileItemFactory();
	
	             boolean isMultipart = ServletFileUpload.isMultipartContent(request);
	             
	             ServletFileUpload upload = new ServletFileUpload(factory);
	             Map<String, List<FileItem>> file = upload.parseParameterMap(request);
             //while
	             
             for (Entry thisEntry : file.entrySet()) {
                 List value = (List) thisEntry.getValue();
                 for (Iterator it = value.iterator(); it.hasNext();) {
                     FileItem uploadItem = (FileItem) it.next();
                     csvfile = uploadItem.getInputStream();
                 } // end of for loop
             }
	
	            InputStreamReader isr = new InputStreamReader(csvfile);
	            BufferedReader reader = new BufferedReader(isr);
	           
	            String text = "";
	            reader.readLine();
	
	                // We read the file line by line and later will be displayed on the browser page.
	            while ((text = reader.readLine()) != null) {
	                String[] columns = text.split(",");
	                System.out.println("count columns" + columns.length);
	                String rowdata = "";
		                for (String value : columns) {
		                    rowdata += "'" + value + "',";
		                }
		               rowdata = rowdata.substring(0, rowdata.length() - 1);
		               String select = category;
		                 try {
		                       Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examdb","root","");
        Statement stmt=con.createStatement();
		                       String query = "insert into hindique(question,optA,optB,optC,optD,answer) values(" + rowdata + ")";
		                       stmt.executeUpdate(query);
		                        out.println("Successfully uploaded");
		                      }
		                      catch (ClassNotFoundException | SQLException e) {
		                       out.println("Error Try Again"+e.getMessage());
		                       } 
	                 }

           }
          catch (IOException | FileUploadException e) {
        	  
        }
    }

   
}